Programming is the act of writing instructions for a computer to solve problems or perform tasks.

In this topic, you will connect the idea of programming to everyday step-by-step instructions, like writing steps for an ATM to withdraw cash.
