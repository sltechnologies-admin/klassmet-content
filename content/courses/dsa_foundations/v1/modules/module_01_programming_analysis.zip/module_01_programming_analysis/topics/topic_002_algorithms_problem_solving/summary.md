An algorithm is a finite, ordered set of steps to solve a problem.

In this topic, you will learn that an algorithm is the *logic* behind a solution — it is not tied to any programming language or hardware.
