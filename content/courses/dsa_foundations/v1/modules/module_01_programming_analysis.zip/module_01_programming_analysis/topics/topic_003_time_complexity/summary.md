Time complexity measures how execution time grows as the input size increases.

In this topic, you will learn how to analyse loops and algorithms to determine how fast or slow they are as input grows — like comparing a linear phone book search versus a binary search.
