Space complexity measures the extra memory used by an algorithm as input size grows.

In this topic, you will understand that algorithms don't just take time — they also consume memory, and learning to measure that is essential for efficient programming.
